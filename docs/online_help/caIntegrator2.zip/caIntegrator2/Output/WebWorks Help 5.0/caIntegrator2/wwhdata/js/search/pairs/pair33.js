function FileData_Pairs(x)
{
x.t("describes","search");
x.t("results","overview");
x.t("results","viewing");
x.t("results","section");
x.t("results","caintegrator2");
x.t("search","results");
x.t("queries","topics");
x.t("viewing","search");
x.t("section","describes");
x.t("section","include");
x.t("include","following");
x.t("topics","section");
x.t("following","search");
x.t("returns","queries");
x.t("caintegrator2","returns");
}
