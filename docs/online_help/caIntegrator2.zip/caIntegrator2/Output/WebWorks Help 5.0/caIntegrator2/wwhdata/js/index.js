function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("A",null,null,"002");
var B=A.fA("Application Support",new Array("8#1122280"));
A=P.fA("C",null,null,"002");
B=A.fA("caIntegrator2");
var C=B.fA("workspace",new Array("5#1122586"));
A=P.fA("H",null,null,"002");
B=A.fA("hierarchy of objects, NCIA",new Array("28#1076814","38#1164562"));
A=P.fA("I",null,null,"002");
B=A.fA("I-SPY");
C=B.fA("logging out",new Array("7#1111569"));
C=B.fA("tabs",new Array("6#1122024"));
A=P.fA("K",null,null,"002");
B=A.fA("Kaplan-Meier for Gene Expression Data");
C=B.fA("redrawing plot",new Array("42#1073592"));
C=B.fA("simple search",new Array("42#1073579"));
A=P.fA("L",null,null,"002");
B=A.fA("logging out");
C=B.fA("I-SPY",new Array("7#1111569"));
B=A.fA("logout link",new Array("7#1111569"));
A=P.fA("N",null,null,"002");
B=A.fA("NCICB Application Support",new Array("8#1122280"));
A=P.fA("O",null,null,"002");
B=A.fA("objects in NCIA, hierarchy of",new Array("28#1076814","38#1164562"));
A=P.fA("R",null,null,"002");
B=A.fA("redrawing");
C=B.fA("K-M Gene Expression plot",new Array("42#1073592"));
A=P.fA("S",null,null,"002");
B=A.fA("simple searches");
C=B.fA("K-M Gene Expression Data",new Array("42#1073579"));
A=P.fA("T",null,null,"002");
B=A.fA("tabs, shown",new Array("6#1122024"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 3;
}
