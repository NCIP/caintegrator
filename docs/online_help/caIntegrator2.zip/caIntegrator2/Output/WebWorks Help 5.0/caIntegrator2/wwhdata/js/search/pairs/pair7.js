function FileData_Pairs(x)
{
x.t("getting","started");
x.t("link","upper");
x.t("upper","right-hand");
x.t("corner","page");
x.t("right-hand","corner");
x.t("logging","getting");
x.t("logging","logging");
x.t("logging","log");
x.t("started","caintegrator2");
x.t("click","logout");
x.t("logout","link");
x.t("caintegrator2","logging");
x.t("caintegrator2","click");
x.t("log","caintegrator2");
}
