function FileData_Pairs(x)
{
x.t("study","editing");
x.t("study","configuring");
x.t("study","creating");
x.t("editing","study");
x.t("new","study");
x.t("configuring","deploying");
x.t("deploying","study");
x.t("creating","new");
}
