function FileData_Pairs(x)
{
x.t("gene","expression");
x.t("studies","performing");
x.t("asdl","fkh");
x.t("queries","gene");
x.t("queries","asdl");
x.t("queries","analyzing");
x.t("analyzing","studies");
x.t("performing","data");
x.t("value","plot");
x.t("expression","value");
x.t("data","analysis");
x.t("plot","genomic");
x.t("analysis","gene");
x.t("genomic","queries");
}
