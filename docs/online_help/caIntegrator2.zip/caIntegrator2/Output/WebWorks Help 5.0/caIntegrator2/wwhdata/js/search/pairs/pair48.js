function FileData_Pairs(x)
{
x.t("gene","expression");
x.t("studies","performing");
x.t("queries","gene");
x.t("queries","analyzing");
x.t("queries","asd");
x.t("analyzing","studies");
x.t("cinical","queries");
x.t("performing","data");
x.t("value","plot");
x.t("expression","value");
x.t("data","analysis");
x.t("plot","cinical");
x.t("analysis","gene");
x.t("asd","lfkj");
}
