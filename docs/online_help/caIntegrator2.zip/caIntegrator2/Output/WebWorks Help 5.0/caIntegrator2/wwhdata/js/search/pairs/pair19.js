function FileData_Pairs(x)
{
x.t("study","editing");
x.t("study","configuring");
x.t("editing","genomic");
x.t("new","study");
x.t("configuring","deploying");
x.t("deploying","study");
x.t("creating","new");
x.t("data","editing");
x.t("data","creating");
x.t("genomic","data");
}
