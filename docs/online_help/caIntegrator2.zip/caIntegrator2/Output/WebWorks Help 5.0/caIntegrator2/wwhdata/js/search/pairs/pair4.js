function FileData_Pairs(x)
{
x.t("ogging","login");
x.t("getting","started");
x.t("logging","ogging");
x.t("logging","getting");
x.t("started","caintegrator2");
x.t("login","page");
x.t("enter","username");
x.t("username","password");
x.t("page","enter");
x.t("caintegrator2","logging");
}
