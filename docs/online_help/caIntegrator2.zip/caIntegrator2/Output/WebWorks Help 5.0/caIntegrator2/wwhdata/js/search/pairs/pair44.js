function FileData_Pairs(x)
{
x.t("kaplan-meier","plots");
x.t("gene","expression");
x.t("studies","performing");
x.t("creating","kaplan-meier");
x.t("analyzing","studies");
x.t("performing","data");
x.t("expression","analyzing");
x.t("expression","plot");
x.t("data","analysis");
x.t("plots","plot");
x.t("plot","gene");
x.t("analysis","creating");
}
