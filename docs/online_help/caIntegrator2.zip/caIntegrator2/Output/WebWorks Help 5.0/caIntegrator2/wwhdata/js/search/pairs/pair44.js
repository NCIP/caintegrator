function FileData_Pairs(x)
{
x.t("asdfl","lasdlfk");
x.t("kaplan-meier","plots");
x.t("studies","performing");
x.t("creating","kaplan-meier");
x.t("queries","asdfl");
x.t("queries","analyzing");
x.t("queries","plot");
x.t("analyzing","studies");
x.t("performing","data");
x.t("data","analysis");
x.t("plots","plot");
x.t("plot","queries");
x.t("analysis","creating");
}
