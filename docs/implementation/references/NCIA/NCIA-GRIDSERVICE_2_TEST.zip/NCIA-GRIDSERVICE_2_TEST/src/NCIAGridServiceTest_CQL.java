import gov.nih.nci.cagrid.cqlquery.CQLQuery;
import gov.nih.nci.cagrid.cqlresultset.CQLQueryResults;
import gov.nih.nci.cagrid.data.client.DataServiceClient;
import gov.nih.nci.cagrid.data.utilities.CQLQueryResultsIterator;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;
import java.util.Properties;

public class NCIAGridServiceTest_CQL {

	// Data service Client that communicates with the Grid services.

	private DataServiceClient client = null;

	// Passed parameters

	public String serviceURL;
	public String wsddFile;

	// File writer for the output

	private FileWriter outputWriter = null;

	// This root class is the top level of a generic Grid Service Framework
	// that may eventually be integrated into a web-based application
	// For now, it is merely called via a command-line series of arguments


	public static void main(String[] args) {

		// Obtain the properties

		Properties testProperties = NCIAGridServiceTest_CQL.readProperties("conf/NCIAGrid.properties");

		// Obtain the CQL Queries

		String[] queryList = NCIAGridServiceTest_CQL.readQueries("conf/NCIA_CQL.xml");

		// Let the user know what is happening

		System.out.println("Service URL: "+testProperties.getProperty("serviceURL"));
		System.out.println("WSDD: "+testProperties.getProperty("wsdd"));
		System.out.println("Number of queries: "+queryList.length);

		// Create the Root client

		NCIAGridServiceTest_CQL gtr = new NCIAGridServiceTest_CQL(testProperties.getProperty("serviceURL"),
				testProperties.getProperty("username"),
				testProperties.getProperty("password"),
				testProperties.getProperty("wsdd"),
				testProperties.getProperty("outfile"));

		gtr.runXMLTests(queryList);
//		gtr.runDeserializerTests(queryList);
	}

	public NCIAGridServiceTest_CQL(String serviceURL, String username, String password, String wsddFile, String outfile)  {
		super();

		// Set up a couple of basic values

		this.serviceURL = serviceURL;
		this.wsddFile = wsddFile;

		try   {
			client = new DataServiceClient(serviceURL);

			// Open the output writer

			try {
				outputWriter = new FileWriter(outfile);
			}
			catch(IOException ioe)   {
				System.out.println("IO Exception opening output file");
				System.exit(1);
			}	
		}
		catch(Exception e)   {
			System.out.println(e.toString());
			e.printStackTrace();
		}
	}

	public void runDeserializerTests(String[] queries) {

		System.out.println("Running Deserialized Tests");

		try  {
			CQLQuery query = new CQLQuery();

			// This work gets done as a series of tests

			for (int i=0;i<queries.length;i++)   {

				int counter = i+1;
				System.out.println("Sending query "+counter);

				StringReader queryReader = new StringReader(queries[i]);

				query = (CQLQuery)gov.nih.nci.cagrid.common.Utils.deserializeObject(queryReader,CQLQuery.class);

				try  {
					outputWriter.write(queries[i]+"\n");

					CQLQueryResults results = client.query(query);


					Iterator iter = new CQLQueryResultsIterator(results,
							NCIAGridServiceTest_CQL.class.getResourceAsStream(wsddFile));

					int resultsCounter = 0;
					while (iter.hasNext()) {
						resultsCounter++;
						java.lang.Object result =  iter.next();
						outputWriter.write(result.toString()+"\n");
					}

					outputWriter.write("\n");
					outputWriter.flush();

					System.out.println("Query "+counter+" returned "+resultsCounter+" objects");

				}
				catch(Exception e)  {
					outputWriter.write("Error in query:\n"+queries[i]+"\n");
					outputWriter.write(e.toString());
					outputWriter.flush();
					System.out.println("Query "+counter+" threw exception, see output for details");
				}
			}
		}
		catch(Exception ex)  {
			System.out.println("Exception creating CQLQuery Object: \n"+ex.toString());
		}
	}
	public void runXMLTests(String queries[])  {

		System.out.println("Running XML Tests");

		try  {

			CQLQuery query = new CQLQuery();

			// This work gets done as a series of tests

			for (int i=0;i<queries.length;i++)   {

				int counter = i+1;
				System.out.println("Sending query "+counter);

				StringReader queryReader = new StringReader(queries[i]);

				query = (CQLQuery)gov.nih.nci.cagrid.common.Utils.deserializeObject(queryReader,CQLQuery.class);

				try  {

					CQLQueryResults results = client.query(query);

					Iterator iter = new CQLQueryResultsIterator(results,Boolean.TRUE);

					StringBuffer outputBuffer = new StringBuffer();

					int resultsCounter=0;
					while (iter.hasNext()) {
						resultsCounter++;
						java.lang.Object result = iter.next();
						outputBuffer.append(result.toString()+"\n");
					}

					System.out.println("Query "+counter+" returned "+resultsCounter+" objects");

					outputWriter.write(queries[i]+"\n");
					outputWriter.write(outputBuffer.toString()+"\n");
					outputWriter.flush();
				}
				catch(Exception e)  {
					outputWriter.write("Error in query:\n"+queries[i]+"\n");
					outputWriter.write(e.toString());
					outputWriter.flush();
					System.out.println("Query "+counter+" threw exception, see output for details");
				}
			}
		}
		catch(Exception ex)  {
			System.out.println(ex.toString());
		}
	}
	private static Properties readProperties(String propFileName)  {
		// Open the properties file

		Properties theProperties = new Properties();

		try {
			theProperties.load(new FileInputStream(propFileName));
		}
		catch(FileNotFoundException fnf)   {
			System.out.println("Could not find properties file "+propFileName);
			System.exit(1);
		}
		catch(IOException ioe)   {
			System.out.println("IO Exception loading properties file");
			System.exit(1);
		}

		return theProperties;
	}

	private static String[] readQueries(String queryFile) {

		StringBuffer queryString = new StringBuffer();
		String[] theQueries = new String[1];

		try {
			FileReader fr = new FileReader(queryFile);

			// Read the file

			int c = fr.read();
			while (c != -1)  {
				queryString.append((char)c);
				c = fr.read();
			}

			// Break into constituent queries 

			theQueries = queryString.toString().split("<SPLIT>");
		}
		catch(FileNotFoundException fnf)   {
			System.out.println("Could not find query file "+queryFile);
			System.exit(1);
		}
		catch(IOException ioe)   {
			System.out.println("IO Exception loading query file");
			System.exit(1);
		}

		return theQueries;
	}
}


