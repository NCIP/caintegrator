function FileData_Pairs(x)
{
x.t("getting","started");
x.t("upper","right-hand");
x.t("corner","page");
x.t("right-hand","corner");
x.t("logging","getting");
x.t("logging","logging");
x.t("logging","log");
x.t("started","caintegrator");
x.t("click","logout");
x.t("caintegrator","logging");
x.t("caintegrator","click");
x.t("linkin","upper");
x.t("logout","linkin");
x.t("log","caintegrator");
}
