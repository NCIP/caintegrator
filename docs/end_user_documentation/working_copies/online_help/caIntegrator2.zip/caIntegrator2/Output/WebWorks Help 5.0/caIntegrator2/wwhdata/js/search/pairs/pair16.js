function FileData_Pairs(x)
{
x.t("study","working");
x.t("working","annotations");
x.t("new","study");
x.t("overview","working");
x.t("overview","creating");
x.t("creating","new");
x.t("annotations","overview");
}
