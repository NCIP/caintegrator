function WWHBookData_ALinks(l)
{
}
