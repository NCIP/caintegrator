package ucar.nc2.adde;

import ucar.nc2.Structure;
import ucar.ma2.DataType;
import ucar.nc2.dataset.NetcdfDataset;

/**
 * A Variable implemented through an ADDE server.
 *  *
 * @author caron
 * @version $Revision: 51 $ $Date: 2006-07-12 17:13:13Z $
 */
public class AddeVariable extends ucar.nc2.dataset.VariableDS {
  private int nparam;

  public AddeVariable( NetcdfDataset ncfile, Structure parentStructure, String shortName,
       DataType dataType, String dims, String units, String desc, int nparam) {

    super(ncfile, null, parentStructure, shortName, dataType, dims, units, desc);
    this.nparam = nparam;
  }

  int getParam() { return nparam; }

}
