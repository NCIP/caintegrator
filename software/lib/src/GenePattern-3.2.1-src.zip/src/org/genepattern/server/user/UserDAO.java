/*
 The Broad Institute
 SOFTWARE COPYRIGHT NOTICE AGREEMENT
 This software and its documentation are copyright (2003-2009) by the
 Broad Institute/Massachusetts Institute of Technology. All rights are
 reserved.
 
 This software is supplied without any warranty or guaranteed support
 whatsoever. Neither the Broad Institute nor MIT can be responsible for its
 use, misuse, or functionality.
 */

package org.genepattern.server.user;

// Generated Sep 21, 2006 12:36:06 PM by Hibernate Tools 3.1.0.beta5

import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.genepattern.server.database.BaseDAO;
import org.genepattern.server.database.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Home object for domain model class User.
 *
 * @see org.genepattern.server.user.User
 * @author Hibernate Tools
 */
public class UserDAO extends BaseDAO {

    public static final Logger log = Logger.getLogger(UserDAO.class);

    public User findById(String id) {
        if (id == null) {
            return null;
        }
        return (User) HibernateUtil.getSession().get("org.genepattern.server.user.User", id);
    }
    
    public User findByIdIgnoreCase(String id) {
        if (id == null) {
            return null;
        }
        
        Criteria criteria = HibernateUtil.getSession().createCriteria(User.class);
        Criterion criterion = Restrictions.ilike("userId", id);
        criteria.add(criterion);

        List results = criteria.list();
        if (results != null && results.size() > 0) {
            return (User) results.get(0);
        }
        return null;
    }
    
    public List<User> getAllUsers() {
        List<User> users = 
            HibernateUtil.getSession().createQuery(
                    "from org.genepattern.server.user.User order by userId").list();
        return users;
    }

    public void setProperty(String userId, String key, String value) {
        UserProp userProp = getProperty(userId, key);
        if (userProp != null) {
            userProp.setValue(value);
        }
    }

    public String getPropertyValue(String userId, String key, String defaultValue) {
        UserProp prop = getProperty(userId, key);
        if (prop == null) {
            return defaultValue;
        }
        if (prop.getValue() == null) {
            prop.setValue(defaultValue);
        }
        return prop.getValue();
    }

    public UserProp getProperty(String userId, String key) {
        return getProperty(userId, key, null);
    }

    public UserProp getProperty(String userId, String key, String defaultValue) {
        UserProp rval = null;
        User user = findById(userId);
        if (user == null) {
            log.error("Error in UserDAO.getProperty("+userId+", "+key+"): User not found: "+userId);
        }
        if (user != null) {
            Set<UserProp> userProps = user.getProps();
            for(UserProp prop : userProps) {
                if (key.equals(prop.getKey())) {
                    rval = prop;
                    return prop;
                }
            }
            
            rval = new UserProp();
            rval.setGpUserId(userId);
            rval.setKey(key);
            rval.setValue(defaultValue);
            userProps.add(rval);
        }
        return rval;
    }

    /**
     * Get the value of the 'showExecutionLogs' property for the user.
     * @param userId
     * @return false if the value is not set for the given userId
     */
    public boolean getPropertyShowExecutionLogs(String userId) {
        String showExecutionLogsPropValue = getPropertyValue(userId, "showExecutionLogs", String.valueOf(false));
        return Boolean.valueOf( showExecutionLogsPropValue );
    }

}
