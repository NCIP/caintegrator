package test.gov.nih.nci.security.acegi.sdk.domain;

public class Chromosome {
	private String junk;

	public Chromosome(String junk1){
		this.junk=junk1;
	}
	
	public String getJunk() {
		return junk;
	}

	public void setJunk(String junk) {
		this.junk = junk;
	}
}
