README for NetAffx Copy Number Probesets CSV annotation file

Copyright 2008-2009, Affymetrix Inc.
All Rights Reserved

The contents of this CSV file are covered by the terms of use or
license located at http://www.affymetrix.com/site/terms.affx

Array names: Genome Wide SNP 5.0, Genome Wide SNP 6.0,  Cytogenetics_Array

This README provides a guide to the contents of the CSV files
containing annotations for the copy number probesets on the Affymetrix
Mapping arrays.

Contents
--------

I. General Notes
   A. Informative Header
   B. File format conventions

II. CSV file: Column Descriptions

I. General Notes
-----------------

I.A. Informative Header

     The CSV file contains an informative header consisting of a set of
   key=value attributes describing the data within the file. This
   includes details about the array design and the NetAffx release on
   which the data in the file are based. The keys do not contain
   spaces, but the values may.

   For compatibility with Expression Console (EC) and Affymetrix Power
   Tools (APT) software, each attribute-containing line of the
   informative header starts with '#%' while descriptive comment lines
   of the header start with '##'.

   The first non-commented row of the CSV file is a column header,
   containing the primary column titles.

   Description of header keys:

   General information:
      create_date     - date the CSV file was created
      chip_type       - offical designation of the chip (a.k.a. array_type)
      lib_set_name    - array name portion of library file name
      lib_set_version - array version portion of library file name

   Genome information:
      genome-species                - genus and species of organism
      genome-version                - version used during array annotation
      genome-version-ucsc           - UCSC version tag for genome assembly
      genome-version-ncbi           - NCBI version tag for genome assembly
      genome-version-create_date    - genome assembly release date

   NetAffx information:
      netaffx-annotation-date                    - NetAffx release date
      netaffx-annotation-netaffx-build           - NetAffx release number
      netaffx-annotation-tabular-format-version  - version of the file format
      netaffx-annotation-docgen-method           - specific class of the "docgen" software used to generate the annotation file
      netaffx-annotation-docgen-version          - version of the "docgen" software used to generate the annotation file


   Source database information:
      dbsnp-version                 - dbSNP version used during array annotation
      dbsnp-date                    - date of dbSNP version release
      dgv-date                      - date of the "Database of Genomic Variants" version release
      dgv-version                   - Database of Genomic Variants release used for array annotation
      hapmap-version                - HapMap version used during array annotation
      hapmap-date                   - date of HapMap version release

 
I.B. File format conventions

   The CSV files follow the conventions of other NetAffx tabular data
files as described at:

http://www.affymetrix.com/support/technical/manual/taf_manual.affx

Missing values  in the  annotations are represented as "---".

II. CSV file: Column Descriptions
---------------------------------
       1. Probe Set ID(CN-xxxxx)

Unique identifier for the probe set.

       2. Chromosome (1-22, X, Y)

The chromosome where the CN probe set maps.

       3. Chromosome Start

The start base position of the 5'-most probe in the probe set.

       4. Chromosome Stop

The end base position of the 3'-most probe in the probe set.

       5. Strand

The strand (of the reference genome) where the CN probe set maps.
Missing values  are represented as "---".

       6. ChrX pseudo-autosomal region 1

This pseudo-autosomal region has the following chromosomal
coordinates:
ChrX:1-2709520
ChrY:1-2709520.

Value is 1 if the CN probe set is located in the p-end pseudo-
autosomal region of chromosome X; otherwise value is 0.

	7. Cytoband

The chromosome band seen on Giemsa-stained chromosomes.
Value is the band number where the CN probe set maps.
 
	8. Associated Gene

Values are a list of genes which the CN probe is associated to
(separated by ///). Values for each gene are transcript
accession // CN probe-gene relationship // distance (value 0 if
within the gene) // UniGene Cluster ID // gene name or
symbol // NCBI Gene ID // GenBank description. The CN probe
could be within the gene region or be upstream or
downstream of the genes. 

	9. Microsatellite

List of microsatellite markers surrounding or overlapping
the CN probe(separated by ///).  Values are "marker accession // CN Probe-marker relationship //
distance from marker to CN Probe".  The CN Probe-marker relationship
could be "upstream" or "downstream" or "within".  The distance field is "0" for
markers that fall "within" the CN Probe.


	10. Fragment Enzyme Type Length Start Stop
Restriction fragments on which the CN Probe is located.
Values are "Enzyme name // Enzyme recognition site // length of the restriction enzyme fragment where
the CN probe set is located in // chromosomal start position
of the fragment // chromosomal stop position of the fragment".

        11. Copy Number Variation

Known Copy Number Variations (CNV) overlapping the corresponding CN probe set.
The CNV regions were obtained from the Database of Genomic Variants at
http://projects.tcag.ca/variations.  Values are "CNV id // genomic location
// Method used to discover the CNV // Reference Pubmed id // Reference
// Variation Type".
 
	12. Probe Count

The values are the total number of probes in the probeset.

	13. ChrX pseudo-autosomal region 2

This pesudo autosomal region has the following chromosomal coordinates:
ChrX: 154584237-154913754
ChrY: 57443437-57772954.

Value is 1 if the CN probe set is located in the pseudo-
autosomal region of chromosome X; otherwise value is 0.
        
        14. SNP Interference

Value is "YES"  if there is a SNP overlapping the CN probe and  "NO" if there is no SNP overlapping
the CN  probe.

        15. % GC

There are two types of  %GC annotations.  "local" and "A/B".  

        16. OMIM

Overlaps of OMIM genes with the probeset.  Values are "OMIM id // Disease title
 // morbid map id // Transcript accession // Location of the probeset relative to the transcript

      This database contains information from the Online Mendelian
      Inheritance in Man (OMIM (TM)) database, which has been obtained under a
      license from the Johns Hopkins University.  This database/product does
      not represent the entire, unmodified OMIM(TM) database, which is
      available in its entirety at www.ncbi.nlm.nih.gov/omim/.

        17. In  Final List

Value is "YES" if the probeset is included in the final version of the library file
and "NO" if the probeset is not included in the final version of the library file.


