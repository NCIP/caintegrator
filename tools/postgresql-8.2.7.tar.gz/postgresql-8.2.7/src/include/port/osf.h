/* $PostgreSQL: pgsql/src/include/port/osf.h,v 1.9 2006/03/11 04:38:38 momjian Exp $ */

#define NOFIXADE
#define DISABLE_XOPEN_NLS
