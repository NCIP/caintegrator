package test.gov.nih.nci.security.acegi;

public class AcegiTestConstants {
	public static final int DESIRED_OBJECTS_SET = 3;
}
