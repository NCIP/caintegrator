README for NetAffx CSV annotation files for Genotyping Products.

Copyright 2006-2008, Affymetrix Inc.
All Rights Reserved

The contents of this CSV file are covered by the terms of use or 
license located at http://www.affymetrix.com/site/terms.affx

Array names:     Mapping 10K Array; Mapping 10K 2.0 Array; Mapping 100K 
Array Set; Mapping 500K Array Set; GenomeWideSNP_5 Array; Targeted Genotyping Panels
Organism:        Homo sapiens

This README provides a guide to the contents of the CSV files 
containing annotations for the Affymetrix Mapping arrays. 

Contents
--------

I. General Notes
   A. Informative Header
   B. File format conventions
   C. Annotation overview

II. CSV file: Column Descriptions

III. References


I. General Notes
-----------------

I.A. Informative header

   The CSV file contains an informative header consisting of a set of
   key=value attributes describing the data within the file. This
   includes details about the array design and the NetAffx release on
   which the data in the file are based. The keys do not contain
   spaces, but the values may.

   For compatibility with Expression Console (EC) and Affymetrix Power
   Tools (APT) software, each attribute-containing line of the
   informative header starts with '#%' while descriptive comment lines
   of the header start with '##'.

   The first non-commented row of the CSV file is a column header,
   containing the primary column titles.

   Description of header keys:

   General information:
      create_date     - date the CSV file was created
      chip_type       - offical designation of the chip (a.k.a. array_type)
      lib_set_name    - array name portion of library file name
      lib_set_version - array version portion of library file name

   Genome information: 
      genome-species                - genus and species of organism
      genome-version                - version used during array annotation
      genome-version-ucsc           - UCSC version tag for genome assembly
      genome-version-ncbi           - NCBI version tag for genome assembly
      genome-version-create_date    - genome assembly release date

   NetAffx information:
      netaffx-annotation-date                    - NetAffx release date
      netaffx-annotation-netaffx-build           - NetAffx release number
      netaffx-annotation-tabular-format-version  - version of the file format
      netaffx-annotation-tabular-data-version    - version of the file data (deprecated, use netaffx-build)

   Source database information:
      dbsnp-version                 - dbSNP version used during array annotation
      dbsnp-date                    - date of dbSNP version release
      hapmap-version                - HapMap version used during array annotation
      hapmap-date                   - date of HapMap version release


I.B. File format conventions

   The CSV files follow the conventions of other NetAffx tabular data 
files as described at:   

http://www.affymetrix.com/support/technical/manual/taf_manual.affx
      
I.C. Annotation overview
  
   SNPs selected for Affymetrix Mapping arrays are from three sources: 
the SNP consortium (TSC, http://snp.cshl.org/), dbSNP 
(http://www.ncbi.nlm.nih.gov/projects/SNP/) and Perlegen Sciences 
(http://www.perlegen.com/). 

   1. Chromosomal positions.
   For SNPs in dbSNP, SNP chromosomal positions are obtained from dbSNP 
database. For SNPs from Perlegen but not yet in dbSNP, the 51-mer 
flanking sequence (SNP in center position, sequence provided by 
Perlegen Sciences) was used to BLAT the reference genome for inferring 
chromosomal positions of SNPs. In rare occasions, a SNP selected at 
design time does not uniquely map to the reference genome at time of 
annotation update. No chromosome positions are reported in those cases.   

   2. Relationship to surrounding genes.
   SNP chromosomal positions were compared with the annotated gene structure 
of Ensembl genes, and the relationship was annotated 
as 5UTR, CDS, 3UTR, and intron when the SNP falls into regions of 5�UTR, 
CDS, 3�UTR, and intron respectively. When a SNP is not within any genes, 
it was annotated as upstream (when the SNP is upstream of the 5� end of 
the gene) or downstream (when the SNP is downstream of the 3� end of 
the gene) relative to the neighboring genes. The distance from the SNP 
to the gene is reported.

   3. Genetic maps.
   This annotation is to provide a rough estimate on SNP genetic 
distances to the p-telomere. Those estimates may be used as seed input 
for linkage analysis programs like MERLIN 
(http://www.sph.umich.edu/csg/abecasis/Merlin/). As a requirement of 
MERLIN, every SNP has to have a unique genetic distance. SNP genetic 
distances were extrapolated from three experimentally obtained genetic 
maps: deCODE map, Marshfield map, and SLM1 map. 
	1). deCODE genetic map was built by genotyping 5,136 
microsatellite markers for 146 families (1), and is available through 
Nature Genetics (see reference).
  	2). Marshfield genetic map (2) was based on CEPH family genotypes 
for 7,740 microsatellite markers, and is available from 
http://research.marshfieldclinic.org/genetics/Map_Markers/maps/IndexMap
Frames.html.     
  	3). SLM1 (SNP Linkage Map) map was generated from unpublished 
data from Affymetrix and Dr. Aravinda Chakravarti group at Johns 
Hopkins University. It was based on genotypes for 2,022 microsatellite 
markers and 6,205 SNPs. 
   Physical locations of markers used in each genetic map were obtained 
from the UCSC database (ftp://genome.ucsc.edu). Markers are removed 
when their genetic order is opposite of their physical order. When 
physically neighboring markers share the same genetic distance, only 
the one with the largest physical position was kept in order that no 
two SNPs have exactly the same genetic distance. Physical positions of 
SNPs and physical locations of the markers in the cleaned genetic maps 
were compared to infer genetic distances for SNPs. We assume that 
genetic distance changes linearly with physical distance between any 
two neighboring markers in each genetic map. 

   4. Enzyme fragment.
   Mapping 10K array uses restriction enzyme XbaI for target 
preparation; Mapping 100K uses XbaI and HindIII; mapping 500K uses NspI 
and StyI.  The values here provide the genomic coordinates of the
restriction fragments and the length of the restriction fragment.  


II. CSV file: Column Descriptions
---------------------------------

       1. Probe Set ID (SNP_A-nnnnnnn)
       
       Unique identifier for the probe set.
       
       2. Affy SNP ID (integer)
       
       	SNP identifier from Affymetrix
        
       3. dbSNP RS ID
       
       	SNP identifier from dbSNP. 
       
       4. Chromosome (1-22, X, Y)
       
       	See "Annotation overview".
       
       5. Physical Position 
       
1-based SNP chromosomal position. See also "Annotation 
overview".
       
       6. Strand (+|-)
       
The strand (of the reference genome) where the SNP is 
mapped. This information may not be the same as that of 
dbSNP for the same SNP. See also "Allele A".
  
       7. ChrX pseudo-autosomal region 1

This pseudo-autosomal region has the following chromosomal
coordinates:
ChrX:1-2709520
ChrY:1-2709520.
       
Value is 1 if the SNP is located in the p-end pseudo-
autosomal region of chromosome X; otherwise value is 0.

       8. Cytoband
       9. Flank
       
Flanking sequences of the SNP with 16 bases on each side of 
the SNP. The two alleles of the SNP are placed in the 
middle within brackets.
 
       10. Allele A
       
At design time, Affymetrix follows its own rules on 
choosing one of the two strands as forward strand (see 
document "allele_naming_convention.pdf" for allele 
definition). As a result, Affymetrix may report alleles 
that are complementary to what are listed in dbSNP for 
the same SNP. Affymetrix defines that the allele in lower 
alphabetical order is the A allele and the other allele 
is the B allele.
 
       11. Allele B
       
       	See definition in "Allele A" above.
       
       12. Associated Gene
       
Values are a list of genes which the SNP is associated to 
(separated by ///). Values for each gene are: "transcript 
accession // SNP-gene relationship // distance (value 0 if 
within the gene) // UniGene Cluster ID // gene name or 
symbol // NCBI Gene ID // GenBank description". The SNP 
could be within the gene region or be upstream or 
downstream of the genes. See "Annotation overview" for 
details.
 
       13. Genetic Map
       
See "Annotation overview" for details on calculation of 
genetic distances. Values listed are "sex-averaged genetic 
distance calculated from deCODE genetic map // ID of first 
deCODE marker used for calculation // ID of second deCODE 
marker used //  // --- /// sex-averaged genetic distance 
calculated from Marshfield genetic map // ID of first 
Marshfield marker // ID of second Marshfield marker // name 
of first Marshfield marker // name of second Marshfield 
marker /// sex-averaged genetic distance calculated from 
SLM1 genetic map // ID of SLM1 marker number 1 // ID of 
SLM1 marker number 2 // TSC (the SNP consortium) ID of SNP 
number 1 // TSC ID of SNP number 2". Note for calculating 
genetic distance from SLM1, pairs marker number 1/ marker 
number 2 or marker number 2/SNP number 1 or SNP number 
1/SNP number 2 may be used. 

       14. Microsatellite
       
Values are "marker upstream of the SNP // upstream // 
distance from marker to SNP /// marker downstream of SNP // 
downstream // distance from SNP to marker" or "marker 
containing the SNP // within // 0 /// marker upstream of 
the SNP // upstream // distance from marker to SNP /// 
marker downstream of SNP // downstream // distance from SNP 
to marker".

       15. Fragment Enzyme Type Length Start Stop
       
Values are "Restriction enzyme // Restriction enzyme recognition site 
// length of the restriction enzyme fragment where the SNP is located in
// 1-based chromosomal start position of the fragment // 1-based chromosomal stop 
position of the fragment". Start position refers to the position of the 
first base of the enzyme recognition sequence at 5' end of 
the fragment; stop position refers to the position of the 
first base of the enzyme recognition sequence at 3' end of 
the fragment.

       16. Allele Frequencies
       
Allele frequencies reported here were obtained from 
experimental data from Affymetrix on different sets of 
individuals. 

Values are a list of allele frequencies for various populations
(separated by "///").  Values for each population are 
"A allele frequency // B allele frequency // Population".

       17. Heterozygous Allele Frequencies
       
Heterozygosity was calculated from the above allele 
frequency data. 

Values are a list of heterozygosity frequencies for various 
populations (separated by "///").  Values for each population
are "Heterozygosity frequency // Population".

       18. Number of individuals/Number of chromosomes
       
For Mapping 500K, values are a list of the number of individuals 
from various populations (separated by "///") used for calculating the 
above allele frequencies.

For other arrays values are a list of the number of chromosomes from various
populations (separated by "///").

For each population the values are "Number of individuals or chromosomes 
// Population".

       19. In Hapmap

This indicates if the corresponding SNP is included in the HapMap project.
Possible values are 'YES' if it is part of HapMap or '---' if either unknown or
not included in the HapMap.

       20. Strand Versus dbSNP

For Mapping arrays, we use a convention to select a reference strand to define A/B
alleles.  This annotation indicates the relationship of this reference strand versus
dbSNP.  Possible values here are 'same', 'reverse' or 'NA'.  'NA' indicates that
the corresponding SNP is not in dbSNP.

       21. Copy Number Variation

Copy Number Variations (CNV) overlapping the corresponding SNP.  The CNV
regions were obtained from the Database of Genomic Variants at 
http://projects.tcag.ca/variations.  Values are "CNV id // genomic location 
// Method used to discover the CNV // Reference Pubmed id // Reference
// Variation Type".


      22. Probe Count

The values are the total number of probes in the probeset.

      23. ChrX pseudo-autosomal region 2

This pesudo autosomal region has the following chromosomal coordinates:
ChrX: 154584237-154913754
ChrY: 57443437-57772954.

Value is 1 if the SNP is located in the pseudo-
autosomal region of chromosome X; otherwise value is 0.

      24. In Final List

Value is "YES" if the probeset is included in the final version of the library file
and "NO" if the probeset is not included in the final version of the library file.

      25. Minor Allele

Values are: minor allele // population.

      26. Minor Allele Frequency

Values are: minor allele frequency // population.

      27. %GC
"% GC" is not a percent, but rather a fraction that is calculated using the following algorithm: for each SNP or CN position in a chromosome, a window of 250,000 bases to each side of that base was used and the fraction of bases that are G and C are calculated.  E.g., if 265,717 bases are G or C, then the fraction is 265,717/500,001 = .5314.  If the position is such that the window is less than 500,001 then the fraction for that base is set to the value for the nearest position that has a full window.  E.g. at the beginning of the chromosome for all base positions less than 250,001, the GC fraction value is set to the value of the 250,001 base position.  Similarly, at the end of each chromosome all positions that are nearer to the end than 250,001 are set to the value of the position at 250,001 from that end.  Position and chromosome values for SNPs and CN probes were mapped to the position of bases in the FASTA files for the build of the genome used in this release of NetAffx, and these bases were then used for all calculations.


III. References

1.	Kong, A., Gudbjartsson, D.F., Sainz, J., Jonsdottir, G.M., Gudjonsson, S.A., 
Richardsson, B., Sigurdardottir, S., Barnard, J., Hallbeck, B., Masson, G., 
Shlien, A., Palsson, S.T., Frigge, M.L., Thorgeirsson, T.E., Gulcher, J.R., 
Stefansson, K. (2002) A high-resolution recombination map of the human 
genome. Nat Genet., 31, 241-247.
2.	Broman, K.W., Murray, J.C., Sheffield, V.C., White, R.L., Weber, J.L. (1998) 
Comprehensive human genetic maps: individual and sex-specific 
variation in recombination. Am J Hum Genet., 63, 861-869.


